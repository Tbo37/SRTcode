Location of external libs
