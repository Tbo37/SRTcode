package org.firstinspires.ftc.teamcode.drivecode;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.IMU;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

@TeleOp(name = "LiftTest", group = "Testing")
public class TestViper extends LinearOpMode {



    private DcMotor viperLeft;
    private DcMotor viperRight;
    private DcMotor viperLeft2;
    private DcMotor viperRight2;


    double speed = 0.8;


    @Override
    public void runOpMode() throws InterruptedException {


        viperLeft2 = hardwareMap.get(DcMotor.class,"vl2");
        viperLeft = hardwareMap.get(DcMotor.class,"vl");
        viperRight = hardwareMap.get(DcMotor.class,"vr");
        viperRight2 = hardwareMap.get(DcMotor.class,"vr2");

        viperRight.setDirection(DcMotorSimple.Direction.REVERSE);


        double speedV = 1;

        waitForStart();

        telemetry.addData("Status", "Initialized");
        telemetry.update();

        while (!isStopRequested()) {

            while (opModeIsActive()) {

                if (gamepad2.right_bumper) {
                    speedV = 0.5;
                }
                else { speedV = 1;
                }

                if (gamepad1.right_bumper) {
                    speed = 0.3;
                }
                else { speed = 1;
                }

                if (gamepad2.dpad_up) {
                    viperLeft.setPower(1*speedV);
                    viperRight.setPower(1*speedV);
                    viperLeft2.setPower(1*speedV);
                    viperRight2.setPower(1*speedV);
                }
                else if (gamepad2.dpad_down) {
                    viperLeft.setPower(-1*speedV);
                    viperRight.setPower(-1*speedV);
                    viperLeft2.setPower(-1*speedV);
                    viperRight2.setPower(-1*speedV);
                }
                else {
                    viperLeft.setPower(0.13);
                    viperRight.setPower(0.13);
                    viperLeft2.setPower(0.13);
                    viperRight2.setPower(0.13);
                }
            }
        }
    }
}
